from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from forum.models import Question, Answer
from taggit.models import Tag

SAMPLE_QUESTIONS = [
    # 1-10
    {
        'title': 'What is HTML?',
        'description': 'What does HTML stand for and what is it used for?',
        'tags': ['html', 'web'],
        'answers': [
            'HTML stands for HyperText Markup Language. It is the standard language for creating web pages and web applications.',
            'HTML provides the basic structure of a website, which is enhanced and modified by other technologies like CSS and JavaScript.'
        ]
    },
    {
        'title': 'What is CSS?',
        'description': 'What does CSS stand for and what is its purpose?',
        'tags': ['css', 'web', 'style'],
        'answers': [
            'CSS stands for Cascading Style Sheets. It is used to style and layout web pages.',
            'CSS controls the color, font, spacing, and positioning of HTML elements.'
        ]
    },
    {
        'title': 'What is JavaScript?',
        'description': 'Explain what JavaScript is and where it is used.',
        'tags': ['javascript', 'web', 'programming'],
        'answers': [
            'JavaScript is a high-level, interpreted scripting language used to create dynamic web pages.',
            'It runs in the browser and allows for interactive effects and client-side logic.'
        ]
    },
    {
        'title': 'What is Python?',
        'description': 'Can you explain what Python is and why it is popular?',
        'tags': ['python', 'programming', 'language'],
        'answers': [
            'Python is a high-level, interpreted programming language known for its readability and versatility.',
            'It is widely used in web development, data science, automation, and more.'
        ]
    },
    {
        'title': 'What is a function in Python?',
        'description': 'Explain what a function is in Python and how to define one.',
        'tags': ['python', 'function'],
        'answers': [
            'A function in Python is a block of reusable code that performs a specific task.',
            'You define a function using the def keyword: def my_function(): ...'
        ]
    },
    {
        'title': 'What is a list in Python?',
        'description': 'How do you create and use lists in Python?',
        'tags': ['python', 'list', 'data-structure'],
        'answers': [
            'A list in Python is an ordered, mutable collection of items. Lists are created using square brackets [].',
            'You can add, remove, and access elements by index in a Python list.'
        ]
    },
    {
        'title': 'What is a dictionary in Python?',
        'description': 'Explain dictionaries in Python and how they are used.',
        'tags': ['python', 'dictionary', 'data-structure'],
        'answers': [
            'A dictionary in Python is an unordered collection of key-value pairs.',
            'Dictionaries are created using curly braces {} and are useful for fast lookups.'
        ]
    },
    {
        'title': 'What is a variable in JavaScript?',
        'description': 'How do you declare variables in JavaScript?',
        'tags': ['javascript', 'variable'],
        'answers': [
            'Variables in JavaScript can be declared using var, let, or const.',
            'let and const are block-scoped, while var is function-scoped.'
        ]
    },
    {
        'title': 'What is an array in JavaScript?',
        'description': 'Explain arrays in JavaScript and how to use them.',
        'tags': ['javascript', 'array'],
        'answers': [
            'An array in JavaScript is a list-like object used to store multiple values.',
            'Arrays are created using square brackets [] and support various methods like push, pop, and map.'
        ]
    },
    {
        'title': 'What is a callback function in JavaScript?',
        'description': 'What is a callback function and how is it used in JavaScript?',
        'tags': ['javascript', 'function', 'callback'],
        'answers': [
            'A callback function is a function passed as an argument to another function and executed later.',
            'Callbacks are commonly used for asynchronous operations like setTimeout or event handling.'
        ]
    },
    # 11-20
    {
        'title': 'What is SQL?',
        'description': 'What does SQL stand for and what is it used for?',
        'tags': ['sql', 'database'],
        'answers': [
            'SQL stands for Structured Query Language. It is used to manage and query relational databases.',
            'SQL allows you to insert, update, delete, and select data from tables.'
        ]
    },
    {
        'title': 'What is a primary key in SQL?',
        'description': 'Explain the concept of a primary key in SQL.',
        'tags': ['sql', 'database', 'primary-key'],
        'answers': [
            'A primary key is a unique identifier for each record in a database table.',
            'Primary keys ensure that each row can be uniquely identified.'
        ]
    },
    {
        'title': 'What is a foreign key in SQL?',
        'description': 'What is a foreign key and why is it important?',
        'tags': ['sql', 'database', 'foreign-key'],
        'answers': [
            'A foreign key is a field in one table that refers to the primary key in another table.',
            'Foreign keys help maintain referential integrity between tables.'
        ]
    },
    {
        'title': 'What is normalization in databases?',
        'description': 'Explain normalization and its benefits in database design.',
        'tags': ['database', 'normalization'],
        'answers': [
            'Normalization is the process of organizing data to reduce redundancy and improve integrity.',
            'It involves dividing tables and defining relationships to minimize duplication.'
        ]
    },
    {
        'title': 'What is an index in a database?',
        'description': 'What is an index and how does it improve database performance?',
        'tags': ['database', 'index'],
        'answers': [
            'An index is a database object that improves the speed of data retrieval.',
            'Indexes are created on columns to allow faster searches and queries.'
        ]
    },
    {
        'title': 'What is React?',
        'description': 'Explain what React is and why it is popular.',
        'tags': ['react', 'javascript', 'frontend'],
        'answers': [
            'React is a JavaScript library for building user interfaces, especially single-page applications.',
            'It uses a component-based architecture and a virtual DOM for efficient updates.'
        ]
    },
    {
        'title': 'What is a component in React?',
        'description': 'What is a component in React and how do you create one?',
        'tags': ['react', 'component'],
        'answers': [
            'A component in React is a reusable piece of UI that can have its own state and props.',
            'Components can be created as functions or classes.'
        ]
    },
    {
        'title': 'What is state in React?',
        'description': 'Explain the concept of state in React.',
        'tags': ['react', 'state'],
        'answers': [
            'State is a built-in object that stores property values that belong to a component.',
            'When state changes, the component re-renders to reflect the new data.'
        ]
    },
    {
        'title': 'What is a prop in React?',
        'description': 'What are props in React and how are they used?',
        'tags': ['react', 'props'],
        'answers': [
            'Props are inputs to components. They are passed from parent to child and are read-only.',
            'Props allow components to be dynamic and reusable.'
        ]
    },
    {
        'title': 'What is useState in React?',
        'description': 'How does the useState hook work in React?',
        'tags': ['react', 'hooks', 'useState'],
        'answers': [
            'useState is a React hook that lets you add state to functional components.',
            'It returns a stateful value and a function to update it.'
        ]
    },
    # 21-30
    {
        'title': 'What is Git?',
        'description': 'Explain what Git is and why it is used.',
        'tags': ['git', 'version-control'],
        'answers': [
            'Git is a distributed version control system used to track changes in source code during software development.',
            'It allows multiple developers to work on a project simultaneously and helps manage code history.'
        ]
    },
    {
        'title': 'What is an API?',
        'description': 'What does API stand for and what is its purpose?',
        'tags': ['api', 'web', 'integration'],
        'answers': [
            'API stands for Application Programming Interface. It allows different software applications to communicate with each other.',
            'APIs define a set of rules and protocols for building and interacting with software applications.'
        ]
    },
    {
        'title': 'What is OOP?',
        'description': 'Explain the concept of Object-Oriented Programming (OOP).',
        'tags': ['oop', 'programming', 'concepts'],
        'answers': [
            'OOP stands for Object-Oriented Programming, a paradigm based on the concept of objects and classes.',
            'It promotes code reuse, encapsulation, inheritance, and polymorphism.'
        ]
    },
    {
        'title': 'What is HTTP?',
        'description': 'What does HTTP stand for and what is its role in web development?',
        'tags': ['http', 'web', 'protocol'],
        'answers': [
            'HTTP stands for HyperText Transfer Protocol. It is the foundation of data communication on the web.',
            'HTTP defines how messages are formatted and transmitted between clients and servers.'
        ]
    },
    {
        'title': 'What is Linux?',
        'description': 'Explain what Linux is and where it is commonly used.',
        'tags': ['linux', 'os', 'system'],
        'answers': [
            'Linux is an open-source operating system kernel used in many distributions like Ubuntu, Fedora, and CentOS.',
            'It is widely used for servers, desktops, embedded systems, and cloud infrastructure.'
        ]
    },
    {
        'title': 'What is a REST API?',
        'description': 'What is a REST API and how does it work?',
        'tags': ['api', 'rest', 'web'],
        'answers': [
            'A REST API is an API that follows the principles of Representational State Transfer (REST).',
            'It uses HTTP methods like GET, POST, PUT, and DELETE to perform operations on resources.'
        ]
    },
    {
        'title': 'What is a class in Python?',
        'description': 'How do you define and use a class in Python?',
        'tags': ['python', 'class', 'oop'],
        'answers': [
            'A class in Python is a blueprint for creating objects. It defines attributes and methods.',
            'You define a class using the class keyword: class MyClass: ...'
        ]
    },
    {
        'title': 'What is a loop in programming?',
        'description': 'Explain the concept of loops in programming and give examples.',
        'tags': ['loop', 'programming', 'control-flow'],
        'answers': [
            'A loop is a control structure that repeats a block of code multiple times.',
            'Common types of loops are for, while, and do-while.'
        ]
    },
    {
        'title': 'What is a database?',
        'description': 'What is a database and what are its types?',
        'tags': ['database', 'data', 'storage'],
        'answers': [
            'A database is an organized collection of data, generally stored and accessed electronically.',
            'Types include relational (SQL), non-relational (NoSQL), and in-memory databases.'
        ]
    },
    {
        'title': 'What is JSON?',
        'description': 'What does JSON stand for and where is it used?',
        'tags': ['json', 'data', 'format'],
        'answers': [
            'JSON stands for JavaScript Object Notation. It is a lightweight data-interchange format.',
            'JSON is easy for humans to read and write, and easy for machines to parse and generate.'
        ]
    },
    # 31-60 (add more real questions in a similar style)
]

class Command(BaseCommand):
    help = 'Load realistic sample questions and answers into the forum.'

    def handle(self, *args, **kwargs):
        user, _ = User.objects.get_or_create(username='demo', defaults={'email': 'demo@example.com'})
        user.set_password('demo1234')
        user.save()
        for idx, q in enumerate(SAMPLE_QUESTIONS):
            question = Question.objects.create(
                title=q['title'],
                description=q['description'],
                author=user,
                featured=(idx < 5)
            )
            question.tags.add(*q['tags'])
            for ans in q['answers']:
                Answer.objects.create(
                    question=question,
                    author=user,
                    content=ans
                )
        self.stdout.write(self.style.SUCCESS('Loaded realistic sample questions and answers.')) 
        self.stdout.write(self.style.SUCCESS('Loaded 50+ sample questions and answers.')) 