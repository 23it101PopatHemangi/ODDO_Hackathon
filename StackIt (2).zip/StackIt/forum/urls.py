from django.urls import path
from . import views

app_name = 'forum'

urlpatterns = [
    path('', views.question_list, name='question_list'),
    path('question/<int:pk>/', views.question_detail, name='question_detail'),
    path('question/new/', views.question_create, name='question_create'),
    path('question/<int:pk>/answer/', views.answer_create, name='answer_create'),
    path('answer/<int:pk>/vote/', views.answer_vote, name='answer_vote'),
    path('answer/<int:pk>/accept/', views.answer_accept, name='answer_accept'),
    path('answer/<int:pk>/like/', views.answer_like, name='answer_like'),
    path('answer/<int:pk>/comment/', views.add_comment, name='add_comment'),
    path('add-qa/', views.add_question_answer, name='add_question_answer'),
    path('about/', views.about, name='about'),
    path('my-questions/', views.my_questions, name='my_questions'),
    path('my-answers/', views.my_answers, name='my_answers'),
    path('profile/', views.profile, name='profile'),
    path('community/', views.community, name='community'),
    path('question/<int:pk>/like/', views.question_like, name='question_like'),
    path('watch-search/', views.watch_search, name='watch_search'),
    path('notifications/', views.notifications, name='notifications'),
    path('answer-request/', views.answer_request, name='answer_request'),
    path('notification/<int:pk>/go/', views.notification_redirect, name='notification_redirect'),
] 