from django.db import models
from django.contrib.auth.models import User
from taggit.managers import TaggableManager
from ckeditor.fields import RichTextField

# Create your models here.

class Question(models.Model):
    title = models.CharField(max_length=200)
    description = RichTextField()
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='questions')
    tags = TaggableManager()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    featured = models.BooleanField(default=False)

    def __str__(self):
        return self.title

class Answer(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='answers')
    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='answers')
    content = RichTextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_accepted = models.BooleanField(default=False)
    upvotes = models.ManyToManyField(User, related_name='answer_upvotes', blank=True)
    downvotes = models.ManyToManyField(User, related_name='answer_downvotes', blank=True)

    def __str__(self):
        return f"Answer by {self.author.username} on {self.question.title}"

    def vote_score(self):
        return self.upvotes.count() - self.downvotes.count()

class AnswerLike(models.Model):
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='liked_answers')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = ('answer', 'user')

class Comment(models.Model):
    answer = models.ForeignKey(Answer, on_delete=models.CASCADE, related_name='comments')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return f"Comment by {self.user.username} on Answer {self.answer.id}"

class QuestionLike(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='likes')
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='liked_questions')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        unique_together = ('question', 'user')

class QuestionWatch(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='question_watches')
    search_text = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    notified = models.BooleanField(default=False)
    def __str__(self):
        return f"{self.user.username} watches '{self.search_text}'"

class Notification(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='notifications')
    message = models.CharField(max_length=255)
    url = models.CharField(max_length=255, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    read = models.BooleanField(default=False)
    def __str__(self):
        return f"Notification for {self.user.username}: {self.message}"
