from django.contrib import admin
from django import forms
from .models import Question, Answer, AnswerLike, Comment, QuestionLike, Notification, QuestionWatch

class AnswerAdminForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = '__all__'
        widgets = {
            'content': forms.Textarea(attrs={'rows': 10, 'cols': 80}),
        }

class AnswerAdmin(admin.ModelAdmin):
    form = AnswerAdminForm
    list_display = ('__str__', 'question', 'author', 'short_content', 'created_at')
    search_fields = ('content', 'author__username', 'question__title')
    list_filter = ('author', 'question')
    fieldsets = (
        (None, {
            'fields': ('question', 'author', 'content', 'is_accepted', 'upvotes', 'downvotes')
        }),
    )
    def short_content(self, obj):
        return (obj.content[:75] + '...') if len(obj.content) > 75 else obj.content
    short_content.short_description = 'Content'

class NotificationAdmin(admin.ModelAdmin):
    list_display = ('user', 'message', 'url', 'created_at', 'read')
    list_filter = ('read', 'created_at', 'user')
    search_fields = ('message', 'user__username', 'url')
    actions = ['mark_as_read']
    def mark_as_read(self, request, queryset):
        queryset.update(read=True)
    mark_as_read.short_description = 'Mark selected notifications as read'

class QuestionWatchAdmin(admin.ModelAdmin):
    list_display = ('user', 'search_text', 'created_at', 'notified')
    list_filter = ('notified', 'created_at', 'user')
    search_fields = ('search_text', 'user__username')

admin.site.register(Question)
admin.site.register(Answer, AnswerAdmin)
admin.site.register(AnswerLike)
admin.site.register(Comment)
admin.site.register(QuestionLike)
admin.site.register(Notification, NotificationAdmin)
admin.site.register(QuestionWatch, QuestionWatchAdmin)
