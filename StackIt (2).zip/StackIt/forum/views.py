from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpResponse
from django.contrib import messages
from .models import Question, Answer, AnswerLike, Comment, QuestionLike, QuestionWatch, Notification
from .forms import QuestionForm, AnswerForm, QuestionAnswerForm
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.core.paginator import Paginator
from django.db.models import Q
from django.db import models
from django.views.decorators.http import require_POST
from taggit.utils import parse_tags
from django.contrib.auth import login, authenticate
from django.core.mail import send_mail
import re

def question_list(request):
    query = request.GET.get('q', '')
    sort = request.GET.get('sort', 'newest')
    tag = request.GET.get('tag', None)
    all_questions = Question.objects.all()
    
    if query:
        all_questions = all_questions.filter(
            Q(title__icontains=query) | Q(description__icontains=query) | Q(tags__name__icontains=query)
        ).distinct()
    if tag:
        all_questions = all_questions.filter(tags__name=tag)
    if sort == 'unanswered':
        all_questions = all_questions.annotate(num_answers=models.Count('answers')).filter(num_answers=0)
    elif sort == 'active':
        all_questions = all_questions.order_by('-updated_at')
    elif sort == 'trending':
        all_questions = all_questions.annotate(num_answers=models.Count('answers')).order_by('-num_answers', '-created_at')
    elif sort == 'featured':
        all_questions = all_questions.filter(featured=True).order_by('-created_at')
    else:  # newest
        all_questions = all_questions.order_by('-created_at')

    paginator = Paginator(all_questions, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    # For sidebar tags
    from taggit.models import Tag
    popular_tags = Tag.objects.annotate(num_questions=models.Count('taggit_taggeditem_items')).order_by('-num_questions')[:10]

    context = {
        'page_obj': page_obj,
        'is_paginated': paginator.num_pages > 1,
        'paginator': paginator,
        'request': request,
        'popular_tags': popular_tags,
    }
    return render(request, 'forum/question_list.html', context)

def question_detail(request, pk):
    question = get_object_or_404(Question, pk=pk)
    answer_form = AnswerForm()
    comment_form = None
    if request.user.is_authenticated:
        comment_form = {'csrf_token': ''}  # Placeholder for template
    return render(request, 'forum/question_detail.html', {
        'question': question,
        'answer_form': answer_form,
        'comment_form': comment_form,
    })

@login_required
def question_create(request):
    if request.method == 'POST':
        form = QuestionForm(request.POST)
        if form.is_valid():
            question = form.save(commit=False)
            question.author = request.user
            question.save()
            form.save_m2m()  # Save tags
            messages.success(request, 'Question created successfully!')
            # Notify users watching this search
            for watch in QuestionWatch.objects.filter(notified=False):
                if watch.search_text.lower() in question.title.lower() or watch.search_text.lower() in question.description.lower():
                    Notification.objects.create(
                        user=watch.user,
                        message=f'A question matching your search "{watch.search_text}" was just asked.',
                        url=f'/question/{question.pk}/'
                    )
                    send_mail(
                        'A question you are watching was asked',
                        f'A question matching your search "{watch.search_text}" was just asked: {question.title}\nView it here: http://127.0.0.1:8000/question/{question.pk}/',
                        'noreply@stackit.com',
                        [watch.user.email],
                        fail_silently=True,
                    )
                    watch.notified = True
                    watch.save()
            return redirect('forum:question_detail', pk=question.pk)
    else:
        form = QuestionForm()
    return render(request, 'forum/question_form.html', {'form': form})

@login_required
def answer_create(request, pk):
    question = get_object_or_404(Question, pk=pk)
    if request.method == 'POST':
        form = AnswerForm(request.POST)
        if form.is_valid():
            answer = form.save(commit=False)
            answer.question = question
            answer.author = request.user
            answer.save()
            messages.success(request, 'Answer posted successfully!')
            # Notify users watching this search
            for watch in QuestionWatch.objects.filter(notified=False):
                if watch.search_text.lower() in question.title.lower() or watch.search_text.lower() in question.description.lower():
                    Notification.objects.create(
                        user=watch.user,
                        message=f'A question matching your search "{watch.search_text}" was just answered.',
                        url=f'/question/{question.pk}/'
                    )
                    send_mail(
                        'A question you are watching was answered',
                        f'A question matching your search "{watch.search_text}" was just answered: {question.title}\nView it here: http://127.0.0.1:8000/question/{question.pk}/',
                        'noreply@stackit.com',
                        [watch.user.email],
                        fail_silently=True,
                    )
                    watch.notified = True
                    watch.save()
            return redirect('forum:question_detail', pk=question.pk)
    else:
        form = AnswerForm()
    return render(request, 'forum/answer_form.html', {'form': form, 'question': question})

@login_required
def answer_vote(request, pk):
    answer = get_object_or_404(Answer, pk=pk)
    vote_type = request.POST.get('vote_type')
    
    if vote_type == 'upvote':
        if request.user in answer.upvotes.all():
            answer.upvotes.remove(request.user)
        else:
            answer.upvotes.add(request.user)
            answer.downvotes.remove(request.user)
    elif vote_type == 'downvote':
        if request.user in answer.downvotes.all():
            answer.downvotes.remove(request.user)
        else:
            answer.downvotes.add(request.user)
            answer.upvotes.remove(request.user)
    
    return JsonResponse({'score': answer.vote_score()})

@login_required
def answer_accept(request, pk):
    answer = get_object_or_404(Answer, pk=pk)
    question = answer.question
    
    # Only question author can accept answers
    if request.user != question.author:
        messages.error(request, 'You can only accept answers to your own questions.')
        return redirect('forum:question_detail', pk=question.pk)
    
    # Unaccept all other answers for this question
    question.answers.update(is_accepted=False)
    # Accept this answer
    answer.is_accepted = True
    answer.save()
    
    messages.success(request, 'Answer accepted!')
    return redirect('forum:question_detail', pk=question.pk)

@login_required
@require_POST
def answer_like(request, pk):
    answer = get_object_or_404(Answer, pk=pk)
    like, created = AnswerLike.objects.get_or_create(answer=answer, user=request.user)
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
    return JsonResponse({'liked': liked, 'like_count': answer.likes.count()})

@login_required
@require_POST
def question_like(request, pk):
    question = get_object_or_404(Question, pk=pk)
    like, created = QuestionLike.objects.get_or_create(question=question, user=request.user)
    if not created:
        like.delete()
        liked = False
    else:
        liked = True
    return JsonResponse({'liked': liked, 'like_count': question.likes.count()})

@login_required
@require_POST
def add_comment(request, pk):
    answer = get_object_or_404(Answer, pk=pk)
    content = request.POST.get('content')
    if content:
        comment = Comment.objects.create(answer=answer, user=request.user, content=content)
        # Notify answer author (if not self)
        if answer.author != request.user:
            Notification.objects.create(
                user=answer.author,
                message=f'Someone commented on your answer.',
                url=f'/question/{answer.question.pk}/'
            )
        # Notify @mentions in comment (case-insensitive)
        from django.contrib.auth.models import User
        import re
        mentioned_usernames = set(re.findall(r'@([\w\-]+)', content))
        # Build a mapping of lowercased usernames to User objects
        all_users = User.objects.all()
        username_map = {u.username.lower(): u for u in all_users}
        for username in mentioned_usernames:
            mentioned_user = username_map.get(username.lower())
            if mentioned_user and mentioned_user != request.user:
                # Show who mentioned and a snippet of the comment (first 80 chars)
                snippet = content[:80] + ("..." if len(content) > 80 else "")
                Notification.objects.create(
                    user=mentioned_user,
                    message=f'{request.user.username} mentioned you in a comment: "{snippet}"',
                    url=f'/question/{answer.question.pk}/'
                )
    return redirect('forum:question_detail', pk=answer.question.pk)

@login_required
def add_question_answer(request):
    if request.method == 'POST':
        form = QuestionAnswerForm(request.POST)
        if form.is_valid():
            question = Question.objects.create(
                title=form.cleaned_data['title'],
                description=form.cleaned_data['description'],
                author=request.user
            )
            # Add tags
            tags = parse_tags(form.cleaned_data['tags'])
            question.tags.add(*tags)
            # Create answer
            Answer.objects.create(
                question=question,
                author=request.user,
                content=form.cleaned_data['answer']
            )
            messages.success(request, 'Question and answer added successfully!')
            return redirect('forum:question_detail', pk=question.pk)
    else:
        form = QuestionAnswerForm()
    return render(request, 'forum/add_question_answer.html', {'form': form})

@login_required
def answer_request(request):
    search_text = request.GET.get('search_text', '').strip()
    if request.method == 'POST':
        answer_text = request.POST.get('answer', '').strip()
        if search_text and answer_text:
            # Create the question
            question = Question.objects.create(
                title=search_text,
                description=search_text,
                author=request.user
            )
            # Create the answer
            Answer.objects.create(
                question=question,
                author=request.user,
                content=answer_text
            )
            # Notify all watchers
            for watch in QuestionWatch.objects.filter(search_text__iexact=search_text, notified=False):
                Notification.objects.create(
                    user=watch.user,
                    message=f'A question you were watching ("{search_text}") has been answered.',
                    url=f'/question/{question.pk}/'
                )
                send_mail(
                    'A question you are watching has been answered',
                    f'A question you were watching ("{search_text}") has been answered. View it here: http://127.0.0.1:8000/question/{question.pk}/',
                    'noreply@stackit.com',
                    [watch.user.email],
                    fail_silently=True,
                )
                watch.notified = True
                watch.save()
            messages.success(request, 'Your answer has been posted!')
            return redirect('forum:question_detail', pk=question.pk)
    return render(request, 'forum/answer_request.html', {'search_text': search_text})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Log the user in after registration
            username = form.cleaned_data.get('username')
            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=username, password=raw_password)
            if user is not None:
                login(request, user)
                messages.success(request, 'Registration successful! Welcome to StackIt.')
                return redirect('forum:question_list')
    else:
        form = UserCreationForm()
    return render(request, 'registration/register.html', {'form': form})

def about(request):
    return render(request, 'about.html')

@login_required
def my_questions(request):
    questions = Question.objects.filter(author=request.user).order_by('-created_at')
    paginator = Paginator(questions, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'page_obj': page_obj,
        'is_paginated': paginator.num_pages > 1,
        'paginator': paginator,
        'request': request,
        'my_questions': True,
    }
    return render(request, 'forum/question_list.html', context)

@login_required
def my_answers(request):
    answers = Answer.objects.filter(author=request.user).select_related('question').order_by('-created_at')
    paginator = Paginator(answers, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        'page_obj': page_obj,
        'is_paginated': paginator.num_pages > 1,
        'paginator': paginator,
        'request': request,
        'my_answers': True,
    }
    return render(request, 'forum/my_answers.html', context)

@login_required
def profile(request):
    if request.method == 'POST':
        form = UserChangeForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('forum:profile')
    else:
        form = UserChangeForm(instance=request.user)
    return render(request, 'forum/profile.html', {'form': form})

def community(request):
    return render(request, 'forum/community.html')

@login_required
@require_POST
def watch_search(request):
    search_text = request.POST.get('search_text', '').strip()
    if search_text:
        QuestionWatch.objects.get_or_create(user=request.user, search_text=search_text)
        messages.success(request, f'You will be notified if someone asks or answers a question about "{search_text}".')
    return redirect(request.META.get('HTTP_REFERER', 'forum:question_list'))

@login_required
def notifications(request):
    notifications = Notification.objects.filter(user=request.user).order_by('-created_at')[:10]
    # Mark as read
    notifications.update(read=True)
    return render(request, 'forum/notifications_dropdown.html', {'notifications': notifications})

@login_required
def notification_redirect(request, pk):
    notification = get_object_or_404(Notification, pk=pk, user=request.user)
    notification.read = True
    notification.save()
    return redirect(notification.url or '/')
